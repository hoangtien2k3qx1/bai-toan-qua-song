package com.hoangtien2k3.RiverCrossingPuzzle;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RiverCrossingPuzzleApplicationTests {

	@Test
	void contextLoads() {
	}

}
